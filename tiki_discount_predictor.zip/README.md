# Tiki Discount Predictor

Ứng dụng Streamlit dự đoán sản phẩm sách nào nên được giảm giá để tăng doanh số.

## Cách sử dụng

1. Cài đặt phụ thuộc:
```
pip install -r requirements.txt
```

2. Chạy ứng dụng:
```
streamlit run app.py
```

3. Dán mô tả sách, chọn ngành hàng, giá, tồn kho v.v và xem kết quả!

## Powered by scikit-learn + Streamlit